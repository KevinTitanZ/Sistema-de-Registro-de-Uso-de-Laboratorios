{
  "nombre": "Programación Avanzada",
  "codigo": "PRG550",
  "docenteId": "074081bb-52ea-4012-8bdd-2cca7cf5dd3a",
  "estudiantes": [
    "bfe64d8b-0c0f-4b70-ae26-cbdab6979f97",
    "9a8f31a4-ef4c-4d96-b8f9-e643c0d7cbe7"
  ]
}
